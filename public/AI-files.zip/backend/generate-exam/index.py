"""
Генерация варианта ОГЭ или ЕГЭ по структуре ФИПИ в .docx.
ИИ создаёт задания строго по структуре реального экзамена (количество заданий,
типы, коды тем — как в ФИПИ). Для каждого задания ИИ генерирует рандомный вариант.
POST / body: {
  examType: "ОГЭ" | "ЕГЭ",
  subject: str,
  teacherName: str,
  teacherSchool: str,
  login: str (optional, для проверки лимита)
}
Возвращает: {docx_b64, filename, examType, subject, structure, answers_docx_b64}
"""
import json
import os
import io
import re
import time
import base64
import random
import urllib.request
import urllib.error

AUTH_URL = os.environ.get("AUTH_FUNCTION_URL", "https://functions.poehali.dev/b08ae7cf-6c0b-4178-acc9-4b62b2c2a61b")

TOKENS_COST_EXAM_TASK = 1500


def spend_ai_tokens(login: str, amount: int, action_label: str = "Экзамен ОГЭ/ЕГЭ") -> tuple[bool, str, float, float]:
    if not login:
        return True, "", 0.0, 0.0
    try:
        req = urllib.request.Request(
            f"{AUTH_URL}?action=spend-tokens",
            data=json.dumps({"login": login, "amount": amount, "action_label": action_label}).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            resp = json.loads(r.read().decode())
        spent_rub = float(resp.get("spent_rub") or 0)
        balance_rub = float(resp.get("balance_rub") or 0)
        return True, "", spent_rub, balance_rub
    except urllib.error.HTTPError as e:
        err_body = {}
        try:
            err_body = json.loads(e.read().decode())
        except Exception:
            pass
        if e.code == 402:
            return False, err_body.get("error", "Недостаточно средств"), 0.0, 0.0
        if e.code == 403:
            return False, err_body.get("error", "Для использования ИИ необходима активная подписка."), 0.0, 0.0
        return True, "", 0.0, 0.0
    except Exception:
        return True, "", 0.0, 0.0


def precheck_ai(login: str, est_tokens: int = 2000):
    """Проверяет ДО обращения к ИИ: подписка и достаточный баланс.
    Возвращает (allowed, http_status, error). Без login — разрешаем."""
    if not login:
        return True, 200, ""
    try:
        req = urllib.request.Request(
            f"{AUTH_URL}?action=precheck-ai",
            data=json.dumps({"login": login, "est_tokens": est_tokens}).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            resp = json.loads(r.read().decode())
        return bool(resp.get("allowed")), 200, ""
    except urllib.error.HTTPError as e:
        err_body = {}
        try:
            err_body = json.loads(e.read().decode())
        except Exception:
            pass
        if e.code == 402:
            return False, 402, err_body.get("error", "Недостаточно средств на балансе ИИ. Пополните баланс.")
        if e.code == 403:
            return False, 403, err_body.get("error", "Для использования ИИ необходима активная подписка.")
        return True, 200, ""
    except Exception:
        return True, 200, ""


from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
}

def _resp(status: int, body: dict) -> dict:
    return {
        "statusCode": status,
        "headers": {**CORS, "Content-Type": "application/json"},
        "body": json.dumps(body, ensure_ascii=False),
        "isBase64Encoded": False,
    }


# ─── ИИ API ───────────────────────────────────────────────────────────────────

YANDEX_GPT_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"


# ─── СТРУКТУРЫ ФИПИ ──────────────────────────────────────────────────────────
# Каждая запись: {num, type: "choice"|"short"|"long", topic, points, instruction}

FIPИ_STRUCTURES = {
    "ОГЭ": {
        "Русский язык": {
            "total": 9,
            "parts": [
                {"num": 1, "type": "essay", "topic": "Сжатое изложение по прослушанному тексту", "points": 7,
                 "instruction": "Напишите сжатое изложение прослушанного текста. Объём — не менее 70 слов."},
                {"num": 2, "type": "choice", "topic": "Синтаксический анализ текста", "points": 2,
                 "instruction": "Прочитайте текст и выполните задание. Укажите верные утверждения о предложениях текста.", "options_count": 4},
                {"num": 3, "type": "choice", "topic": "Пунктуационный анализ", "points": 2,
                 "instruction": "Расставьте знаки препинания. Укажите цифры, на месте которых должны стоять запятые.", "options_count": 4},
                {"num": 4, "type": "choice", "topic": "Синтаксический анализ словосочетания", "points": 1,
                 "instruction": "Замените словосочетание, построенное на основе согласования, синонимичным со связью управление.", "options_count": 4},
                {"num": 5, "type": "choice", "topic": "Орфографический анализ", "points": 1,
                 "instruction": "Укажите варианты ответов, в которых дано верное объяснение написания слова.", "options_count": 4},
                {"num": 6, "type": "short", "topic": "Анализ содержания текста", "points": 1,
                 "instruction": "Прочитайте текст. Проанализируйте содержание. Укажите верные утверждения."},
                {"num": 7, "type": "choice", "topic": "Анализ средств выразительности", "points": 1,
                 "instruction": "Укажите предложение, в котором средством выразительности речи является метафора.", "options_count": 4},
                {"num": 8, "type": "short", "topic": "Лексический анализ", "points": 1,
                 "instruction": "Найдите в тексте синоним/антоним/фразеологизм к указанному слову и запишите его."},
                {"num": 9, "type": "essay", "topic": "Сочинение-рассуждение", "points": 9,
                 "instruction": "Напишите сочинение-рассуждение. Объём — не менее 70 слов. Приведите примеры из текста."},
            ]
        },
        "Математика": {
            "total": 25,
            "parts": [
                {"num": 1, "type": "short", "topic": "Вычисления с натуральными числами и дробями", "points": 1,
                 "instruction": "Вычислите значение выражения. Запишите ответ."},
                {"num": 2, "type": "short", "topic": "Арифметика: степени, корни, стандартный вид", "points": 1,
                 "instruction": "Вычислите. Ответ запишите в виде числа."},
                {"num": 3, "type": "short", "topic": "Прикладная задача на проценты/пропорции", "points": 1,
                 "instruction": "Прочитайте условие и найдите ответ. Запишите его числом."},
                {"num": 4, "type": "short", "topic": "Геометрия: площади, периметры, теорема Пифагора", "points": 1,
                 "instruction": "По данным рисунка найдите значение величины. Запишите ответ."},
                {"num": 5, "type": "short", "topic": "Алгебра: уравнения и неравенства", "points": 1,
                 "instruction": "Решите уравнение. Запишите ответ."},
                {"num": 6, "type": "short", "topic": "Статистика и теория вероятностей", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 7, "type": "short", "topic": "Функции и графики", "points": 1,
                 "instruction": "По графику функции найдите значение. Запишите ответ."},
                {"num": 8, "type": "short", "topic": "Числовые последовательности", "points": 1,
                 "instruction": "Найдите значение выражения. Запишите ответ."},
                {"num": 9, "type": "short", "topic": "Геометрия: треугольники и четырёхугольники", "points": 1,
                 "instruction": "По данным рисунка найдите угол или длину. Запишите ответ."},
                {"num": 10, "type": "short", "topic": "Геометрия: окружность", "points": 1,
                 "instruction": "Решите задачу на окружность. Запишите ответ."},
                {"num": 11, "type": "short", "topic": "Координатная геометрия", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 12, "type": "short", "topic": "Комбинаторика", "points": 1,
                 "instruction": "Решите комбинаторную задачу. Запишите ответ."},
                {"num": 13, "type": "long", "topic": "Алгебра: нелинейные уравнения/системы", "points": 2,
                 "instruction": "Решите задание. Запишите полное решение."},
                {"num": 14, "type": "long", "topic": "Практическая задача (реальная математика)", "points": 2,
                 "instruction": "Решите задачу. Запишите полное решение."},
                {"num": 15, "type": "long", "topic": "Геометрия: доказательство и вычисление", "points": 3,
                 "instruction": "Докажите утверждение или найдите значение. Запишите полное решение."},
            ]
        },
        "Физика": {
            "total": 25,
            "parts": [
                {"num": 1, "type": "choice", "topic": "Механика: кинематика", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 2, "type": "choice", "topic": "Механика: динамика", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 3, "type": "choice", "topic": "Статика и законы сохранения", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 4, "type": "choice", "topic": "Молекулярная физика и термодинамика", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 5, "type": "choice", "topic": "Электростатика", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 6, "type": "choice", "topic": "Электрический ток", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 7, "type": "choice", "topic": "Магнетизм и электромагнетизм", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 8, "type": "choice", "topic": "Оптика", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 9, "type": "multi", "topic": "Установление соответствий / множественный выбор", "points": 2,
                 "instruction": "Установите соответствие или выберите все верные утверждения. Запишите цифры ответа."},
                {"num": 10, "type": "multi", "topic": "Работа с графиком / таблицей", "points": 2,
                 "instruction": "Проанализируйте данные. Выберите верные утверждения. Запишите цифры."},
                {"num": 11, "type": "short", "topic": "Расчётная задача по механике", "points": 2,
                 "instruction": "Решите расчётную задачу. Запишите полное решение с формулами."},
                {"num": 12, "type": "short", "topic": "Расчётная задача по термодинамике", "points": 2,
                 "instruction": "Решите расчётную задачу. Запишите полное решение."},
                {"num": 13, "type": "short", "topic": "Расчётная задача по электричеству", "points": 2,
                 "instruction": "Решите расчётную задачу. Запишите полное решение."},
                {"num": 14, "type": "long", "topic": "Комплексная расчётная задача", "points": 3,
                 "instruction": "Решите задачу. Запишите полное решение с объяснениями."},
                {"num": 15, "type": "long", "topic": "Экспериментальное задание", "points": 3,
                 "instruction": "Опишите опыт или решите экспериментальную задачу."},
            ]
        },
        "Химия": {
            "total": 22,
            "parts": [
                {"num": 1, "type": "choice", "topic": "Строение атома. Периодическая таблица", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 2, "type": "choice", "topic": "Химическая связь и строение вещества", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 3, "type": "choice", "topic": "Классификация и свойства неорганических веществ", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 4, "type": "choice", "topic": "Оксиды: химические свойства", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 5, "type": "choice", "topic": "Кислоты и основания", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 6, "type": "choice", "topic": "Соли: получение и свойства", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 7, "type": "multi", "topic": "Химические реакции: классификация и условия", "points": 2,
                 "instruction": "Выберите все верные утверждения. Запишите цифры."},
                {"num": 8, "type": "multi", "topic": "Соответствие формул/названий/классов", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры в таблицу."},
                {"num": 9, "type": "short", "topic": "Уравнения реакций. Типы реакций", "points": 2,
                 "instruction": "Закончите уравнения реакций. Определите тип каждой реакции."},
                {"num": 10, "type": "short", "topic": "Окислительно-восстановительные реакции", "points": 2,
                 "instruction": "Расставьте коэффициенты методом электронного баланса."},
                {"num": 11, "type": "short", "topic": "Основы органической химии", "points": 1,
                 "instruction": "Определите формулу или класс органического соединения. Запишите ответ."},
                {"num": 12, "type": "long", "topic": "Расчётная задача по химии", "points": 4,
                 "instruction": "Решите задачу. Запишите полное решение с уравнениями реакций."},
            ]
        },
        "Биология": {
            "total": 26,
            "parts": [
                {"num": 1, "type": "choice", "topic": "Клетка: строение и функции органоидов", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 2, "type": "choice", "topic": "Обмен веществ и энергии в клетке", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 3, "type": "choice", "topic": "Деление клетки. Размножение организмов", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 4, "type": "choice", "topic": "Наследственность и изменчивость", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 5, "type": "choice", "topic": "Эволюция органического мира", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 6, "type": "choice", "topic": "Экология: взаимоотношения организмов", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 7, "type": "choice", "topic": "Строение и жизнедеятельность растений", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 8, "type": "choice", "topic": "Строение и жизнедеятельность животных", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 9, "type": "multi", "topic": "Множественный выбор: биологические объекты", "points": 2,
                 "instruction": "Выберите три верных ответа из шести. Запишите цифры."},
                {"num": 10, "type": "multi", "topic": "Установление последовательности / соответствия", "points": 2,
                 "instruction": "Установите соответствие или последовательность. Запишите цифры."},
                {"num": 11, "type": "short", "topic": "Анализ биологического текста или рисунка", "points": 2,
                 "instruction": "Рассмотрите рисунок и ответьте на вопросы. Запишите ответы."},
                {"num": 12, "type": "long", "topic": "Развёрнутый ответ на биологическую задачу", "points": 3,
                 "instruction": "Ответьте на вопрос. Обоснуйте ответ примерами."},
            ]
        },
        "История": {
            "total": 23,
            "parts": [
                {"num": 1, "type": "choice", "topic": "Древняя Русь (IX—XII вв.)", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 2, "type": "choice", "topic": "Русские земли в XII—XV вв.", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 3, "type": "choice", "topic": "Московское государство XV—XVII вв.", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 4, "type": "choice", "topic": "Россия в XVIII веке", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 5, "type": "choice", "topic": "Россия в первой половине XIX века", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 6, "type": "choice", "topic": "Россия во второй половине XIX века", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 7, "type": "choice", "topic": "Россия в начале XX века", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 8, "type": "multi", "topic": "СССР 1920—1930-е гг.", "points": 2,
                 "instruction": "Выберите все верные утверждения. Запишите цифры."},
                {"num": 9, "type": "multi", "topic": "ВОВ 1941—1945 гг.", "points": 2,
                 "instruction": "Установите соответствие событий и дат. Запишите цифры."},
                {"num": 10, "type": "short", "topic": "СССР во второй половине XX века", "points": 2,
                 "instruction": "Рассмотрите задание и запишите развёрнутый ответ."},
                {"num": 11, "type": "short", "topic": "Россия в 1990-е — 2000-е гг.", "points": 2,
                 "instruction": "Ответьте на вопрос. Приведите примеры из истории."},
                {"num": 12, "type": "long", "topic": "Анализ исторического источника", "points": 3,
                 "instruction": "Прочитайте фрагмент источника и ответьте на вопросы."},
            ]
        },
        "Обществознание": {
            "total": 24,
            "parts": [
                {"num": 1, "type": "choice", "topic": "Человек в системе общественных отношений", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 2, "type": "choice", "topic": "Сферы общественной жизни", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 3, "type": "choice", "topic": "Экономика и экономические отношения", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 4, "type": "choice", "topic": "Социальные отношения", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 5, "type": "choice", "topic": "Политика и право", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 6, "type": "multi", "topic": "Определения понятий и их признаки", "points": 2,
                 "instruction": "Выберите все верные суждения. Запишите цифры."},
                {"num": 7, "type": "multi", "topic": "Установление соответствий", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры в таблицу."},
                {"num": 8, "type": "short", "topic": "Анализ схемы или таблицы", "points": 2,
                 "instruction": "Проанализируйте данные и ответьте на вопросы."},
                {"num": 9, "type": "long", "topic": "Мини-сочинение по обществоведческому понятию", "points": 4,
                 "instruction": "Раскройте смысл понятия. Составьте два предложения, содержащих информацию о данном понятии."},
            ]
        },
        "Информатика": {
            "total": 15,
            "parts": [
                {"num": 1, "type": "short", "topic": "Системы счисления. Перевод чисел", "points": 1,
                 "instruction": "Переведите число и запишите ответ."},
                {"num": 2, "type": "short", "topic": "Кодирование информации", "points": 1,
                 "instruction": "Решите задачу на кодирование. Запишите ответ."},
                {"num": 3, "type": "short", "topic": "Логика. Алгебра логики", "points": 1,
                 "instruction": "Вычислите логическое выражение. Запишите ответ."},
                {"num": 4, "type": "short", "topic": "Алгоритмы: блок-схемы и трассировка", "points": 2,
                 "instruction": "Проследите выполнение алгоритма и запишите результат."},
                {"num": 5, "type": "short", "topic": "Программирование: базовые конструкции", "points": 2,
                 "instruction": "Определите, что выведет программа. Запишите ответ."},
                {"num": 6, "type": "short", "topic": "Электронные таблицы", "points": 1,
                 "instruction": "Определите значение ячейки по формуле. Запишите ответ."},
                {"num": 7, "type": "short", "topic": "Сети и телекоммуникации", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 8, "type": "long", "topic": "Написание программы на языке программирования", "points": 4,
                 "instruction": "Напишите программу на языке Python (или Pascal). Запишите код."},
            ]
        },
        "География": {
            "total": 30,
            "parts": [
                {"num": 1, "type": "short", "topic": "Источники географической информации", "points": 1,
                 "instruction": "Определите по условию и запишите ответ."},
                {"num": 2, "type": "short", "topic": "Земля как планета. Глобус и карта", "points": 1,
                 "instruction": "Определите координаты или расстояния по карте."},
                {"num": 3, "type": "short", "topic": "Литосфера и рельеф", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 4, "type": "short", "topic": "Атмосфера и климат", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 5, "type": "short", "topic": "Мировой океан и гидросфера", "points": 1,
                 "instruction": "Определите и запишите ответ."},
                {"num": 6, "type": "choice", "topic": "Природные зоны мира", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 7, "type": "choice", "topic": "Страны и народы мира", "points": 1,
                 "instruction": "Выберите один верный ответ.", "options_count": 4},
                {"num": 8, "type": "multi", "topic": "Природа России: регионы и объекты", "points": 2,
                 "instruction": "Выберите все верные утверждения. Запишите цифры."},
                {"num": 9, "type": "long", "topic": "Комплексная задача по географии России", "points": 3,
                 "instruction": "Решите задачу. Запишите развёрнутый ответ."},
            ]
        },
        "Иностранный язык": {
            "total": 35,
            "parts": [
                {"num": 1, "type": "choice", "topic": "Чтение: понимание основного содержания текста", "points": 1,
                 "instruction": "Прочитайте текст и выберите верные утверждения.", "options_count": 2},
                {"num": 2, "type": "short", "topic": "Чтение: понимание структуры текста", "points": 1,
                 "instruction": "Восстановите текст, вставив пропущенные части."},
                {"num": 3, "type": "short", "topic": "Чтение: детальное понимание", "points": 1,
                 "instruction": "Прочитайте и ответьте на вопросы по содержанию."},
                {"num": 4, "type": "short", "topic": "Лексика и грамматика: заполнение пропусков", "points": 1,
                 "instruction": "Заполните пропуски, используя слова из списка."},
                {"num": 5, "type": "short", "topic": "Грамматика: словообразование", "points": 1,
                 "instruction": "Образуйте слово нужной части речи. Запишите ответ."},
                {"num": 6, "type": "long", "topic": "Письмо: личное письмо другу", "points": 10,
                 "instruction": "Напишите личное письмо другу по переписке. Объём — 100–120 слов."},
            ]
        },
    },
    "ЕГЭ": {
        "Русский язык": {
            "total": 27,
            "parts": [
                {"num": 1, "type": "multi", "topic": "Информационная обработка текста", "points": 1,
                 "instruction": "Укажите варианты ответов, в которых даны верные характеристики текста."},
                {"num": 2, "type": "short", "topic": "Значение слова в тексте", "points": 1,
                 "instruction": "Самостоятельно подберите слово, которое должно стоять на месте пропуска."},
                {"num": 3, "type": "short", "topic": "Стилистический анализ", "points": 1,
                 "instruction": "Прочитайте фрагмент словарной статьи. Определите значение слова."},
                {"num": 4, "type": "short", "topic": "Орфографический анализ (приставки, корни)", "points": 1,
                 "instruction": "Укажите варианты ответов с верным объяснением написания приставки/корня."},
                {"num": 5, "type": "short", "topic": "Орфографический анализ (суффиксы)", "points": 1,
                 "instruction": "Укажите варианты ответов, где слово написано правильно."},
                {"num": 6, "type": "short", "topic": "Лексические нормы", "points": 1,
                 "instruction": "Отредактируйте предложение: исправьте лексическую ошибку."},
                {"num": 7, "type": "multi", "topic": "Морфологические нормы", "points": 1,
                 "instruction": "Укажите все варианты с грамматической ошибкой в образовании формы слова."},
                {"num": 8, "type": "short", "topic": "Синтаксические нормы (соответствие)", "points": 5,
                 "instruction": "Установите соответствие между грамматическими ошибками и предложениями."},
                {"num": 9, "type": "multi", "topic": "Орфография: НЕ/НИ и другие", "points": 1,
                 "instruction": "Укажите все варианты ответов, где выделенные слова пишутся слитно."},
                {"num": 10, "type": "multi", "topic": "Орфография: Н/НН", "points": 1,
                 "instruction": "Укажите варианты ответов, где пишется НН."},
                {"num": 11, "type": "multi", "topic": "Пунктуация: запятые при причастных/деепричастных оборотах", "points": 1,
                 "instruction": "Укажите цифры, на месте которых должны стоять запятые."},
                {"num": 12, "type": "multi", "topic": "Пунктуация: тире, двоеточие, запятые в сложном предложении", "points": 1,
                 "instruction": "Укажите цифры, на месте которых должны стоять запятые."},
                {"num": 13, "type": "multi", "topic": "Пунктуация: вводные слова и обращения", "points": 1,
                 "instruction": "Укажите цифры, на месте которых должны стоять запятые."},
                {"num": 14, "type": "multi", "topic": "Пунктуация: сложноподчинённые предложения", "points": 1,
                 "instruction": "Укажите все цифры, на месте которых должны стоять запятые."},
                {"num": 15, "type": "short", "topic": "Пунктуация: двоеточие и тире в бессоюзных предложениях", "points": 1,
                 "instruction": "Укажите цифры, на месте которых должно стоять тире/двоеточие."},
                {"num": 16, "type": "short", "topic": "Пунктуация: знаки препинания в конструкциях с союзом И", "points": 1,
                 "instruction": "Укажите все цифры, на месте которых должны стоять запятые."},
                {"num": 17, "type": "short", "topic": "Пунктуация: сложное предложение с разными связями", "points": 1,
                 "instruction": "Укажите все цифры, на месте которых должны стоять запятые."},
                {"num": 18, "type": "short", "topic": "Средства связи в тексте", "points": 1,
                 "instruction": "Найдите предложение, которое связано с предыдущим при помощи указанного средства."},
                {"num": 19, "type": "multi", "topic": "Языковые средства выразительности", "points": 4,
                 "instruction": "Прочитайте рецензию. Вставьте пропущенные термины из списка."},
                {"num": 20, "type": "essay", "topic": "Сочинение по прочитанному тексту", "points": 25,
                 "instruction": "Напишите сочинение по прочитанному тексту. Сформулируйте и прокомментируйте проблему. Объём — не менее 150 слов."},
            ]
        },
        "Математика (профиль)": {
            "total": 19,
            "parts": [
                {"num": 1, "type": "short", "topic": "Простейшие вычисления и практические задачи", "points": 1,
                 "instruction": "Вычислите. Запишите ответ."},
                {"num": 2, "type": "short", "topic": "Геометрия на плоскости", "points": 1,
                 "instruction": "Найдите значение. Запишите ответ."},
                {"num": 3, "type": "short", "topic": "Решение уравнений", "points": 1,
                 "instruction": "Решите уравнение. Запишите ответ."},
                {"num": 4, "type": "short", "topic": "Теория вероятностей и статистика", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 5, "type": "short", "topic": "Функции: область определения, значения", "points": 1,
                 "instruction": "Найдите значение функции. Запишите ответ."},
                {"num": 6, "type": "short", "topic": "Производная и первообразная", "points": 1,
                 "instruction": "Найдите производную/первообразную. Запишите ответ."},
                {"num": 7, "type": "short", "topic": "Стереометрия: тела и их сечения", "points": 2,
                 "instruction": "Найдите объём или площадь. Запишите ответ."},
                {"num": 8, "type": "short", "topic": "Неравенства и системы неравенств", "points": 1,
                 "instruction": "Решите неравенство. Запишите ответ."},
                {"num": 9, "type": "short", "topic": "Прикладная задача (экономика/финансы)", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 10, "type": "short", "topic": "Числовые и буквенные выражения", "points": 1,
                 "instruction": "Преобразуйте выражение. Запишите ответ."},
                {"num": 11, "type": "long", "topic": "Тригонометрические уравнения", "points": 3,
                 "instruction": "Решите уравнение. Запишите полное решение."},
                {"num": 12, "type": "long", "topic": "Исследование функции и построение графика", "points": 4,
                 "instruction": "Исследуйте функцию. Найдите точки экстремума. Постройте эскиз графика."},
                {"num": 13, "type": "long", "topic": "Стереометрия: доказательство и вычисление", "points": 4,
                 "instruction": "Докажите утверждение. Найдите объём или угол."},
                {"num": 14, "type": "long", "topic": "Неравенства повышенной сложности", "points": 4,
                 "instruction": "Решите неравенство. Запишите полное решение."},
                {"num": 15, "type": "long", "topic": "Прикладная экономическая задача", "points": 4,
                 "instruction": "Решите задачу. Запишите полное решение."},
                {"num": 16, "type": "long", "topic": "Планиметрия: доказательство и вычисление", "points": 4,
                 "instruction": "Решите задачу. Запишите полное решение."},
                {"num": 17, "type": "long", "topic": "Параметры и теория чисел", "points": 4,
                 "instruction": "Решите задачу с параметром. Запишите полное решение."},
            ]
        },
        "Математика (база)": {
            "total": 20,
            "parts": [
                {"num": 1, "type": "short", "topic": "Вычисления с числами и дробями", "points": 1,
                 "instruction": "Вычислите. Запишите ответ."},
                {"num": 2, "type": "short", "topic": "Алгебра: уравнения", "points": 1,
                 "instruction": "Решите уравнение. Запишите ответ."},
                {"num": 3, "type": "short", "topic": "Прикладная задача на проценты", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 4, "type": "short", "topic": "Функции и графики", "points": 1,
                 "instruction": "По графику определите значение. Запишите ответ."},
                {"num": 5, "type": "short", "topic": "Геометрия: площади и объёмы", "points": 1,
                 "instruction": "Найдите площадь или объём. Запишите ответ."},
                {"num": 6, "type": "short", "topic": "Теория вероятностей", "points": 1,
                 "instruction": "Найдите вероятность. Запишите ответ."},
                {"num": 7, "type": "short", "topic": "Практическая задача", "points": 1,
                 "instruction": "Решите задачу из реальной жизни. Запишите ответ."},
                {"num": 8, "type": "long", "topic": "Алгебра: системы уравнений и неравенств", "points": 2,
                 "instruction": "Решите систему. Запишите полное решение."},
                {"num": 9, "type": "long", "topic": "Геометрия: вычисление с доказательством", "points": 2,
                 "instruction": "Решите задачу. Запишите полное решение."},
                {"num": 10, "type": "long", "topic": "Прикладная задача повышенного уровня", "points": 2,
                 "instruction": "Решите задачу. Запишите полное решение."},
            ]
        },
        "Физика": {
            "total": 30,
            "parts": [
                {"num": 1, "type": "multi", "topic": "Механика: кинематика и динамика", "points": 2,
                 "instruction": "Выберите два верных утверждения. Запишите цифры."},
                {"num": 2, "type": "multi", "topic": "Статика. Законы сохранения в механике", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 3, "type": "multi", "topic": "МКТ и термодинамика", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 4, "type": "multi", "topic": "Электрическое поле и постоянный ток", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 5, "type": "multi", "topic": "Магнитное поле и электромагнитная индукция", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 6, "type": "multi", "topic": "Колебания и волны. Оптика", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 7, "type": "multi", "topic": "Квантовая физика и атомное ядро", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 8, "type": "short", "topic": "Соответствие физических величин и единиц измерения", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры."},
                {"num": 9, "type": "short", "topic": "Графическое представление процессов", "points": 2,
                 "instruction": "Проанализируйте графики и запишите ответ."},
                {"num": 10, "type": "short", "topic": "Расчётная задача по механике", "points": 3,
                 "instruction": "Решите задачу. Запишите полное решение с формулами."},
                {"num": 11, "type": "short", "topic": "Расчётная задача по МКТ/термодинамике", "points": 3,
                 "instruction": "Решите задачу. Запишите полное решение."},
                {"num": 12, "type": "short", "topic": "Расчётная задача по электричеству", "points": 3,
                 "instruction": "Решите задачу. Запишите полное решение."},
                {"num": 13, "type": "long", "topic": "Комплексная расчётная задача", "points": 4,
                 "instruction": "Решите задачу. Запишите полное решение с объяснениями."},
            ]
        },
        "Химия": {
            "total": 34,
            "parts": [
                {"num": 1, "type": "short", "topic": "Строение атома. Периодический закон", "points": 1,
                 "instruction": "Запишите ответ."},
                {"num": 2, "type": "short", "topic": "Электронная конфигурация атомов", "points": 1,
                 "instruction": "Запишите ответ."},
                {"num": 3, "type": "short", "topic": "Химическая связь и строение вещества", "points": 1,
                 "instruction": "Запишите ответ."},
                {"num": 4, "type": "short", "topic": "Классификация неорганических веществ", "points": 1,
                 "instruction": "Запишите ответ."},
                {"num": 5, "type": "multi", "topic": "Химические свойства: оксиды и гидроксиды", "points": 2,
                 "instruction": "Выберите верные утверждения. Запишите цифры."},
                {"num": 6, "type": "multi", "topic": "Химические свойства металлов", "points": 2,
                 "instruction": "Выберите верные утверждения. Запишите цифры."},
                {"num": 7, "type": "multi", "topic": "Химические свойства неметаллов", "points": 2,
                 "instruction": "Выберите верные утверждения. Запишите цифры."},
                {"num": 8, "type": "short", "topic": "Реакции ионного обмена", "points": 2,
                 "instruction": "Запишите уравнения реакций в ионном виде."},
                {"num": 9, "type": "short", "topic": "Окислительно-восстановительные реакции", "points": 2,
                 "instruction": "Расставьте коэффициенты методом электронного баланса."},
                {"num": 10, "type": "short", "topic": "Органическая химия: строение и свойства", "points": 2,
                 "instruction": "Запишите ответ."},
                {"num": 11, "type": "short", "topic": "Органические реакции", "points": 2,
                 "instruction": "Составьте уравнения реакций."},
                {"num": 12, "type": "long", "topic": "Расчётная задача по химии", "points": 4,
                 "instruction": "Решите задачу. Запишите полное решение."},
            ]
        },
        "Биология": {
            "total": 28,
            "parts": [
                {"num": 1, "type": "multi", "topic": "Биология как наука. Клетка", "points": 2,
                 "instruction": "Выберите два верных утверждения. Запишите цифры."},
                {"num": 2, "type": "multi", "topic": "Организм: жизнедеятельность и размножение", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 3, "type": "multi", "topic": "Генетика и наследственность", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 4, "type": "multi", "topic": "Эволюция и экология", "points": 2,
                 "instruction": "Выберите два верных утверждения."},
                {"num": 5, "type": "short", "topic": "Соответствие: биологические объекты", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры."},
                {"num": 6, "type": "short", "topic": "Последовательность биологических процессов", "points": 2,
                 "instruction": "Установите правильную последовательность. Запишите цифры."},
                {"num": 7, "type": "short", "topic": "Биологический рисунок: анализ и подписи", "points": 3,
                 "instruction": "Рассмотрите рисунок. Ответьте на вопросы."},
                {"num": 8, "type": "long", "topic": "Развёрнутый ответ: биологические задачи", "points": 3,
                 "instruction": "Ответьте на вопрос. Приведите объяснения."},
                {"num": 9, "type": "long", "topic": "Генетическая задача", "points": 3,
                 "instruction": "Решите генетическую задачу. Запишите схему скрещивания и выводы."},
            ]
        },
        "История": {
            "total": 25,
            "parts": [
                {"num": 1, "type": "short", "topic": "Хронология событий российской истории", "points": 1,
                 "instruction": "Расположите события в хронологическом порядке. Запишите цифры."},
                {"num": 2, "type": "short", "topic": "Исторические термины и понятия", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры."},
                {"num": 3, "type": "multi", "topic": "Период Древней Руси и раздробленности", "points": 2,
                 "instruction": "Выберите верные утверждения. Запишите цифры."},
                {"num": 4, "type": "multi", "topic": "Московское государство XV–XVII вв.", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 5, "type": "multi", "topic": "Россия в XVIII — первой половине XIX в.", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 6, "type": "multi", "topic": "Россия во второй половине XIX — нач. XX в.", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 7, "type": "multi", "topic": "СССР: революция, НЭП, индустриализация", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 8, "type": "multi", "topic": "ВОВ и послевоенное восстановление", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 9, "type": "short", "topic": "Анализ исторического источника", "points": 3,
                 "instruction": "Прочитайте фрагмент. Ответьте на вопросы."},
                {"num": 10, "type": "long", "topic": "Историческое сочинение", "points": 11,
                 "instruction": "Напишите историческое сочинение по одному из периодов. Укажите не менее двух событий, деятеля, причинно-следственные связи."},
            ]
        },
        "Обществознание": {
            "total": 25,
            "parts": [
                {"num": 1, "type": "short", "topic": "Теоретические вопросы: общество и человек", "points": 1,
                 "instruction": "Запишите слово, пропущенное в схеме/таблице."},
                {"num": 2, "type": "multi", "topic": "Человек в обществе. Деятельность", "points": 2,
                 "instruction": "Выберите верные суждения. Запишите цифры."},
                {"num": 3, "type": "short", "topic": "Соответствие: понятия и определения", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры."},
                {"num": 4, "type": "multi", "topic": "Экономика: рынок, фирма, государство", "points": 2,
                 "instruction": "Выберите верные суждения."},
                {"num": 5, "type": "multi", "topic": "Социальные отношения и стратификация", "points": 2,
                 "instruction": "Выберите верные суждения."},
                {"num": 6, "type": "multi", "topic": "Политика: государство и власть", "points": 2,
                 "instruction": "Выберите верные суждения."},
                {"num": 7, "type": "multi", "topic": "Право: конституционное, гражданское, трудовое", "points": 2,
                 "instruction": "Выберите верные суждения."},
                {"num": 8, "type": "short", "topic": "Анализ данных таблицы/диаграммы", "points": 3,
                 "instruction": "Проанализируйте данные. Ответьте на вопросы."},
                {"num": 9, "type": "long", "topic": "Мини-эссе по обществоведческому высказыванию", "points": 6,
                 "instruction": "Выберите одно высказывание и напишите мини-эссе. Раскройте смысл. Приведите аргументы. Объём — не менее 150 слов."},
            ]
        },
        "Информатика": {
            "total": 27,
            "parts": [
                {"num": 1, "type": "short", "topic": "Системы счисления", "points": 1,
                 "instruction": "Запишите ответ."},
                {"num": 2, "type": "short", "topic": "Кодирование информации", "points": 1,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 3, "type": "short", "topic": "Таблицы истинности и логика", "points": 1,
                 "instruction": "Определите значение выражения. Запишите ответ."},
                {"num": 4, "type": "short", "topic": "Алгоритмы: исполнители и трассировка", "points": 1,
                 "instruction": "Проследите выполнение алгоритма. Запишите результат."},
                {"num": 5, "type": "short", "topic": "Программирование: базовые задачи", "points": 2,
                 "instruction": "Определите результат программы. Запишите ответ."},
                {"num": 6, "type": "short", "topic": "Электронные таблицы", "points": 1,
                 "instruction": "Вычислите значение по формуле. Запишите ответ."},
                {"num": 7, "type": "short", "topic": "Базы данных: запросы и выборки", "points": 2,
                 "instruction": "Решите задачу. Запишите ответ."},
                {"num": 8, "type": "short", "topic": "Графы и деревья", "points": 2,
                 "instruction": "Решите задачу на графах. Запишите ответ."},
                {"num": 9, "type": "long", "topic": "Программирование: написание и отладка кода", "points": 4,
                 "instruction": "Напишите программу на Python. Запишите код."},
            ]
        },
        "География": {
            "total": 34,
            "parts": [
                {"num": 1, "type": "short", "topic": "Топографические карты и ориентирование", "points": 1,
                 "instruction": "Определите по карте и запишите ответ."},
                {"num": 2, "type": "short", "topic": "Земля в Солнечной системе. Движения Земли", "points": 1,
                 "instruction": "Запишите ответ."},
                {"num": 3, "type": "multi", "topic": "Литосфера: строение и процессы", "points": 2,
                 "instruction": "Выберите верные утверждения. Запишите цифры."},
                {"num": 4, "type": "multi", "topic": "Атмосфера и климатические пояса", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 5, "type": "multi", "topic": "Мировой океан и воды суши", "points": 2,
                 "instruction": "Выберите верные утверждения."},
                {"num": 6, "type": "short", "topic": "Природные зоны и биосфера", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры."},
                {"num": 7, "type": "short", "topic": "Страны мира: экономика и население", "points": 2,
                 "instruction": "Установите соответствие. Запишите цифры."},
                {"num": 8, "type": "short", "topic": "Регионы и хозяйство России", "points": 3,
                 "instruction": "Ответьте на вопросы по географии России."},
                {"num": 9, "type": "long", "topic": "Комплексная задача по географии", "points": 3,
                 "instruction": "Решите задачу. Запишите развёрнутый ответ с обоснованием."},
            ]
        },
        "Иностранный язык": {
            "total": 46,
            "parts": [
                {"num": 1, "type": "short", "topic": "Аудирование: понимание основного содержания", "points": 1,
                 "instruction": "Определите верные/ложные утверждения. Запишите цифры."},
                {"num": 2, "type": "short", "topic": "Чтение: понимание структуры и содержания", "points": 1,
                 "instruction": "Восстановите текст. Запишите ответ."},
                {"num": 3, "type": "short", "topic": "Чтение: детальное понимание текста", "points": 1,
                 "instruction": "Прочитайте и ответьте на вопросы."},
                {"num": 4, "type": "short", "topic": "Лексика и грамматика: словообразование", "points": 1,
                 "instruction": "Образуйте слово нужной формы. Запишите ответ."},
                {"num": 5, "type": "short", "topic": "Грамматика: глагольные формы и времена", "points": 1,
                 "instruction": "Поставьте глагол в нужную форму. Запишите ответ."},
                {"num": 6, "type": "long", "topic": "Письмо: личное письмо или эссе", "points": 14,
                 "instruction": "Напишите текст по заданию. Объём — 100–150 слов."},
                {"num": 7, "type": "long", "topic": "Устная часть: монолог и диалог (описание)", "points": 20,
                 "instruction": "Опишите фотографию и сравните два изображения. Ответьте на вопросы."},
            ]
        },
        "Литература": {
            "total": 17,
            "parts": [
                {"num": 1, "type": "short", "topic": "Анализ фрагмента прозы: сюжет и герои", "points": 4,
                 "instruction": "Прочитайте фрагмент и ответьте на вопросы."},
                {"num": 2, "type": "short", "topic": "Анализ фрагмента прозы: авторская позиция", "points": 4,
                 "instruction": "Ответьте на вопросы по тексту."},
                {"num": 3, "type": "long", "topic": "Сравнительный анализ: проза и другие тексты", "points": 4,
                 "instruction": "Сравните данный фрагмент с другим произведением. Приведите аргументы."},
                {"num": 4, "type": "short", "topic": "Анализ лирического произведения", "points": 4,
                 "instruction": "Прочитайте стихотворение и ответьте на вопросы."},
                {"num": 5, "type": "long", "topic": "Развёрнутое сочинение по литературе", "points": 10,
                 "instruction": "Напишите развёрнутый ответ (сочинение). Объём — не менее 200 слов."},
            ]
        },
    }
}

# Список предметов по типам экзамена
OGE_SUBJECTS = sorted(FIPИ_STRUCTURES["ОГЭ"].keys())
EGE_SUBJECTS = sorted(FIPИ_STRUCTURES["ЕГЭ"].keys())


def ai_chat(messages: list, max_tokens: int = 3000, req_timeout: int = 65) -> tuple[str, int]:
    api_key = os.environ.get("YANDEXGPT_API_KEY", "").strip()
    folder_id = os.environ.get("YANDEXGPT_FOLDER_ID", "").strip()
    if not api_key or not folder_id:
        raise RuntimeError("YANDEXGPT_API_KEY или YANDEXGPT_FOLDER_ID не заданы")
    yandex_messages = [{"role": m.get("role", "user"), "text": m.get("content", "")} for m in messages]
    payload = {
        "modelUri": f"gpt://{folder_id}/yandexgpt/latest",
        "completionOptions": {
            "stream": False,
            "temperature": 0.6,
            "maxTokens": str(max_tokens),
        },
        "messages": yandex_messages,
    }
    last_err = None
    for attempt in range(1, 4):
        try:
            req = urllib.request.Request(
                YANDEX_GPT_URL,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Api-Key {api_key}",
                    "x-folder-id": folder_id,
                },
            )
            with urllib.request.urlopen(req, timeout=req_timeout) as r:
                body = json.loads(r.read().decode())
            alternatives = (body.get("result") or {}).get("alternatives") or []
            if not alternatives:
                raise RuntimeError(f"ИИ API пустой ответ: {body}")
            text = alternatives[0].get("message", {}).get("text", "").strip()
            if not text:
                raise RuntimeError("ИИ API вернул пустой текст")
            usage = (body.get("result") or {}).get("usage") or {}
            tokens_used = int(usage.get("totalTokens") or usage.get("completionTokens") or 0)
            return text, tokens_used
        except urllib.error.HTTPError as e:
            err_text = e.read().decode(errors="ignore")[:300]
            if e.code in (401, 403):
                raise RuntimeError(f"ИИ API auth error {e.code}: {err_text}")
            last_err = RuntimeError(f"ИИ API HTTP {e.code}: {err_text}")
            if attempt < 3:
                time.sleep(2.0)
        except Exception as e:
            last_err = RuntimeError(f"ИИ API недоступен: {e}")
            if attempt < 3:
                time.sleep(2.0)
    raise last_err or RuntimeError("ИИ API: не удалось получить ответ")


# ─── ГЕНЕРАЦИЯ ЗАДАНИЙ ────────────────────────────────────────────────────────

def extract_json_list(text: str) -> list:
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\[[\s\S]*?\])\s*```", text)
    if fence:
        text = fence.group(1)
    else:
        s = text.find("[")
        e = text.rfind("]")
        if s >= 0 and e > s:
            text = text[s:e + 1]
    return json.loads(text)


def extract_json_obj(text: str) -> dict:
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text)
    if fence:
        text = fence.group(1)
    else:
        s = text.find("{")
        e = text.rfind("}")
        if s >= 0 and e > s:
            text = text[s:e + 1]
    return json.loads(text)


def generate_task(task_def: dict, exam_type: str, subject: str) -> tuple[dict, int]:
    """Генерирует одно задание по шаблону ФИПИ через ИИ."""
    num = task_def["num"]
    topic = task_def["topic"]
    t_type = task_def["type"]
    instruction = task_def["instruction"]
    options_count = task_def.get("options_count", 4)

    if t_type == "choice":
        format_prompt = (
            f'Верни JSON-объект:\n'
            f'{{"question": "текст задания", '
            f'"options": ["1) ...", "2) ...", "3) ...", "4) ..."], '
            f'"answer": "номер правильного ответа: 1, 2, 3 или 4", '
            f'"explanation": "краткое пояснение"}}'
        )
    elif t_type == "multi":
        format_prompt = (
            f'Верни JSON-объект:\n'
            f'{{"question": "текст задания с 5-6 утверждениями/вариантами, пронумерованными 1-5 или 1-6", '
            f'"answer": "цифры верных ответов через запятую, например: 1, 3, 5", '
            f'"explanation": "краткое пояснение"}}'
        )
    elif t_type in ("short", "essay", "long"):
        format_prompt = (
            f'Верни JSON-объект:\n'
            f'{{"question": "полный текст задания или условие задачи", '
            f'"answer": "эталонный ответ или критерии оценивания", '
            f'"explanation": "краткое пояснение или план ответа"}}'
        )
    else:
        format_prompt = (
            f'Верни JSON-объект:\n'
            f'{{"question": "текст задания", "answer": "ответ", "explanation": "пояснение"}}'
        )

    system = (
        f"Ты методист ФИПИ, создающий задания для {exam_type} по предмету «{subject}». "
        f"Задания должны строго соответствовать реальным вариантам ФИПИ: "
        f"сложность, формулировки, стиль — как в официальных КИМ. "
        f"Используй реальные числа, конкретные факты, точные формулировки. "
        f"Отвечай ТОЛЬКО валидным JSON без лишнего текста."
    )
    user = (
        f"Создай задание №{num} ({exam_type}, {subject}).\n"
        f"Тема: «{topic}».\n"
        f"Инструкция для ученика: «{instruction}».\n\n"
        f"{format_prompt}"
    )

    raw, tokens_used = ai_chat(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        max_tokens=1200,
        req_timeout=65,
    )
    data = extract_json_obj(raw)
    return {
        "num": num,
        "type": t_type,
        "topic": topic,
        "points": task_def["points"],
        "instruction": instruction,
        "question": data.get("question", ""),
        "options": data.get("options", []),
        "answer": str(data.get("answer", "")),
        "explanation": data.get("explanation", ""),
    }, tokens_used


# ─── СОЗДАНИЕ DOCX ────────────────────────────────────────────────────────────

def set_font(run, name="Times New Roman", size=12, bold=False, italic=False, color=None):
    run.font.name = name
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = color
    r = run._r
    rPr = r.get_or_add_rPr()
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), name)
    rFonts.set(qn("w:hAnsi"), name)
    rPr.insert(0, rFonts)


def add_heading_para(doc, text, size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER):
    p = doc.add_paragraph()
    p.alignment = align
    run = p.add_run(text)
    set_font(run, size=size, bold=bold)
    return p


def add_body_para(doc, text, indent=0, bold=False, italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(indent)
    run = p.add_run(text)
    set_font(run, size=12, bold=bold, italic=italic)
    return p


def build_variant_docx(exam_type: str, subject: str, tasks: list,
                        teacher_name: str, teacher_school: str,
                        variant_num: int) -> bytes:
    doc = Document()

    # Поля страницы
    for section in doc.sections:
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(3)
        section.right_margin = Cm(1.5)

    # Шапка
    if teacher_school:
        add_heading_para(doc, teacher_school, size=12, bold=False)
    add_heading_para(doc, f"ВАРИАНТ {variant_num}", size=11, bold=False)

    add_heading_para(doc, f"{exam_type}", size=16, bold=True)
    add_heading_para(doc, subject.upper(), size=14, bold=True)

    p_meta = doc.add_paragraph()
    p_meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p_meta.add_run(f"Учитель: {teacher_name}     Дата: ___________     Класс: ___________")
    set_font(run, size=11, italic=True)

    doc.add_paragraph()

    # Инструкция
    instr_p = doc.add_paragraph()
    run = instr_p.add_run("Инструкция по выполнению работы")
    set_font(run, size=12, bold=True)

    instr_text = (
        "На выполнение работы отводится время в соответствии с регламентом экзамена. "
        "Все ответы записывайте в отведённых местах. "
        "При выполнении заданий с кратким ответом запишите ответ в поле для ответа. "
        "При выполнении заданий с развёрнутым ответом запишите решение и ответ полностью."
    )
    add_body_para(doc, instr_text, italic=True)
    doc.add_paragraph()

    # Задания
    current_part = None
    for task in tasks:
        t_type = task["type"]

        # Разделители частей
        if t_type in ("choice", "multi") and current_part != "A":
            current_part = "A"
            p = doc.add_paragraph()
            run = p.add_run("Часть 1")
            set_font(run, size=13, bold=True, color=RGBColor(0x1A, 0x56, 0x9C))
            p2 = doc.add_paragraph()
            run2 = p2.add_run("Выберите один или несколько верных ответов.")
            set_font(run2, size=11, italic=True)
        elif t_type in ("short",) and current_part != "B":
            current_part = "B"
            doc.add_paragraph()
            p = doc.add_paragraph()
            run = p.add_run("Часть 2")
            set_font(run, size=13, bold=True, color=RGBColor(0x1A, 0x56, 0x9C))
            p2 = doc.add_paragraph()
            run2 = p2.add_run("Запишите краткий ответ.")
            set_font(run2, size=11, italic=True)
        elif t_type in ("long", "essay") and current_part != "C":
            current_part = "C"
            doc.add_paragraph()
            p = doc.add_paragraph()
            run = p.add_run("Часть 3")
            set_font(run, size=13, bold=True, color=RGBColor(0x1A, 0x56, 0x9C))
            p2 = doc.add_paragraph()
            run2 = p2.add_run("Задания с развёрнутым ответом.")
            set_font(run2, size=11, italic=True)

        doc.add_paragraph()

        # Номер и тема задания
        p_num = doc.add_paragraph()
        run_num = p_num.add_run(f"Задание {task['num']}. ")
        set_font(run_num, size=12, bold=True)
        run_topic = p_num.add_run(f"({task['topic']})  [{task['points']} б.]")
        set_font(run_topic, size=11, italic=True, color=RGBColor(0x60, 0x60, 0x60))

        # Инструкция для ученика
        p_instr = doc.add_paragraph()
        run_instr = p_instr.add_run(task["instruction"])
        set_font(run_instr, size=11, italic=True)

        # Текст вопроса
        if task.get("question"):
            add_body_para(doc, task["question"])

        # Варианты ответов
        if task.get("options"):
            for opt in task["options"]:
                p_opt = doc.add_paragraph()
                p_opt.paragraph_format.left_indent = Cm(1)
                run_opt = p_opt.add_run(str(opt))
                set_font(run_opt, size=12)

        # Поле для ответа
        if t_type in ("choice", "multi", "short"):
            ans_p = doc.add_paragraph()
            run_ans = ans_p.add_run("Ответ: _______________________________")
            set_font(run_ans, size=11, italic=True, color=RGBColor(0x88, 0x88, 0x88))
        elif t_type in ("long", "essay"):
            add_body_para(doc, "Запишите решение и ответ:", italic=True)
            for _ in range(6):
                line_p = doc.add_paragraph()
                run_line = line_p.add_run("_" * 90)
                set_font(run_line, size=10, color=RGBColor(0xCC, 0xCC, 0xCC))

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def build_answers_docx(exam_type: str, subject: str, tasks: list,
                       teacher_name: str, variant_num: int) -> bytes:
    doc = Document()
    for section in doc.sections:
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(1.5)

    add_heading_para(doc, f"ОТВЕТЫ К ВАРИАНТУ {variant_num}", size=14, bold=True)
    add_heading_para(doc, f"{exam_type}  ·  {subject}", size=12, bold=False)
    p_teacher = doc.add_paragraph()
    p_teacher.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p_teacher.add_run(f"Составил: {teacher_name}")
    set_font(run, size=11, italic=True)
    doc.add_paragraph()

    add_body_para(doc, "ОТВЕТЫ И КРИТЕРИИ ОЦЕНИВАНИЯ", bold=True)
    doc.add_paragraph()

    for task in tasks:
        p_num = doc.add_paragraph()
        run_num = p_num.add_run(f"Задание {task['num']}. {task['topic']}  [{task['points']} б.]")
        set_font(run_num, size=12, bold=True)

        if task.get("answer"):
            p_ans = doc.add_paragraph()
            run_ans = p_ans.add_run(f"Ответ: {task['answer']}")
            set_font(run_ans, size=12, color=RGBColor(0x0A, 0x66, 0x0A))

        if task.get("explanation"):
            p_exp = doc.add_paragraph()
            run_exp = p_exp.add_run(f"Пояснение: {task['explanation']}")
            set_font(run_exp, size=11, italic=True, color=RGBColor(0x44, 0x44, 0x44))

        doc.add_paragraph()

    # Шкала баллов
    total_points = sum(t["points"] for t in tasks)
    doc.add_paragraph()
    add_body_para(doc, "ШКАЛА ПЕРЕВОДА БАЛЛОВ", bold=True)
    add_body_para(doc, f"Максимальный балл: {total_points}")
    add_body_para(doc, f"«5» — {int(total_points * 0.85)}–{total_points} баллов")
    add_body_para(doc, f"«4» — {int(total_points * 0.70)}–{int(total_points * 0.84)} баллов")
    add_body_para(doc, f"«3» — {int(total_points * 0.50)}–{int(total_points * 0.69)} баллов")
    add_body_para(doc, f"«2» — 0–{int(total_points * 0.49)} баллов")

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ─── ХЭНДЛЕР ─────────────────────────────────────────────────────────────────

def _check_limit(login: str) -> dict | None:
    """Проверяет лимит AI. Возвращает ответ-ошибку или None если всё ок."""
    try:
        limit_req = urllib.request.Request(
            f"{AUTH_URL}?action=check-ai-limit",
            data=json.dumps({"login": login}).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(limit_req, timeout=10) as r:
            limit_data = json.loads(r.read().decode())
        if not limit_data.get("allowed"):
            return _resp(429, {"error": limit_data.get("error", "Достигнут лимит ИИ-запросов")})
    except urllib.error.HTTPError as e:
        if e.code == 429:
            err_body = json.loads(e.read().decode() or "{}")
            return _resp(429, {"error": err_body.get("error", "Достигнут лимит ИИ-запросов")})
    except Exception:
        pass
    return None


def handler(event: dict, context) -> dict:
    """
    Генерирует вариант ОГЭ/ЕГЭ по структуре ФИПИ через ИИ (GigaChat).

    Режимы (action в body):
    - subjects (GET): список предметов
    - get_structure: вернуть структуру (количество и типы заданий) без генерации
    - generate_batch: сгенерировать N заданий (batch_indices — список индексов из structure.parts)
    - build_docx: собрать docx из готовых заданий (tasks передаются в body)
    """

    if event.get("httpMethod") == "OPTIONS":
        return {"statusCode": 200, "headers": {**CORS, "Content-Type": "application/json"}, "body": ""}

    if event.get("httpMethod") == "GET":
        qs = event.get("queryStringParameters") or {}
        if qs.get("action") == "subjects":
            exam_type = qs.get("examType", "ОГЭ")
            subjects = OGE_SUBJECTS if exam_type == "ОГЭ" else EGE_SUBJECTS
            return _resp(200, {"subjects": subjects})
        return _resp(200, {"oge_subjects": OGE_SUBJECTS, "ege_subjects": EGE_SUBJECTS})

    if event.get("httpMethod") != "POST":
        return _resp(405, {"error": "Метод не поддерживается"})

    body = json.loads(event.get("body") or "{}")
    action = (body.get("action") or "generate_batch").strip()
    exam_type = (body.get("examType") or "").strip()
    subject = (body.get("subject") or "").strip()

    if exam_type not in ("ОГЭ", "ЕГЭ"):
        return _resp(400, {"error": "Укажите тип экзамена: ОГЭ или ЕГЭ"})
    if not subject:
        return _resp(400, {"error": "Укажите предмет"})

    structure = FIPИ_STRUCTURES.get(exam_type, {}).get(subject)
    if not structure:
        available = OGE_SUBJECTS if exam_type == "ОГЭ" else EGE_SUBJECTS
        return _resp(400, {"error": f"Предмет «{subject}» недоступен для {exam_type}. Доступны: {', '.join(available)}"})

    # ── Получить структуру (без генерации ИИ, мгновенно) ──────────────────────
    if action == "get_structure":
        parts_info = [
            {"num": p["num"], "type": p["type"], "topic": p["topic"], "points": p["points"]}
            for p in structure["parts"]
        ]
        return _resp(200, {
            "examType": exam_type,
            "subject": subject,
            "total": structure["total"],
            "partsCount": len(structure["parts"]),
            "parts": parts_info,
        })

    # ── Генерация батча заданий ────────────────────────────────────────────────
    if action == "generate_batch":
        login = (body.get("login") or "").strip()
        batch_indices = body.get("batchIndices")  # список индексов из structure.parts (0-based)

        if login:
            err = _check_limit(login)
            if err:
                return err

        # Предусматриваем расход: блокируем ИИ при отсутствии подписки/баланса.
        allowed, pc_status, pc_err = precheck_ai(login, est_tokens=3000)
        if not allowed:
            return _resp(pc_status, {"error": pc_err})

        parts = structure["parts"]
        if batch_indices is None:
            # Генерируем все (для обратной совместимости — не используется)
            batch_indices = list(range(len(parts)))

        tasks = []
        total_tokens = 0
        for idx in batch_indices:
            if idx < 0 or idx >= len(parts):
                continue
            task_def = parts[idx]
            try:
                task, _tok = generate_task(task_def, exam_type, subject)
                total_tokens += _tok
            except Exception as e:
                task = {
                    "num": task_def["num"],
                    "type": task_def["type"],
                    "topic": task_def["topic"],
                    "points": task_def["points"],
                    "instruction": task_def["instruction"],
                    "question": f"[Задание по теме: {task_def['topic']}]",
                    "options": [],
                    "answer": "—",
                    "explanation": f"Ошибка: {str(e)[:80]}",
                }
            tasks.append(task)

        _, _, spent_rub, balance_rub = spend_ai_tokens(login, max(total_tokens, 1))

        return _resp(200, {"tasks": tasks, "examType": exam_type, "subject": subject, "spent_rub": spent_rub, "balance_rub": balance_rub})

    # ── Сборка docx из готовых заданий ────────────────────────────────────────
    if action == "build_docx":
        teacher_name = (body.get("teacherName") or "Учитель").strip()
        teacher_school = (body.get("teacherSchool") or "").strip()
        variant_num = int(body.get("variantNum") or random.randint(1, 99))
        tasks = body.get("tasks") or []

        if not tasks:
            return _resp(400, {"error": "Нет заданий для сборки документа"})

        variant_bytes = build_variant_docx(exam_type, subject, tasks, teacher_name, teacher_school, variant_num)
        answers_bytes = build_answers_docx(exam_type, subject, tasks, teacher_name, variant_num)

        safe_subject = re.sub(r"[^\w\-]", "_", subject)
        filename = f"{exam_type}_{safe_subject}_вариант_{variant_num:02d}.docx"
        answers_filename = f"{exam_type}_{safe_subject}_ответы_{variant_num:02d}.docx"
        total_points = sum(t.get("points", 0) for t in tasks)

        return _resp(200, {
            "docx_b64": base64.b64encode(variant_bytes).decode(),
            "answers_docx_b64": base64.b64encode(answers_bytes).decode(),
            "filename": filename,
            "answers_filename": answers_filename,
            "examType": exam_type,
            "subject": subject,
            "variantNum": variant_num,
            "totalTasks": len(tasks),
            "totalPoints": total_points,
            "size": len(variant_bytes),
        })

    return _resp(400, {"error": f"Неизвестный action: {action}"})